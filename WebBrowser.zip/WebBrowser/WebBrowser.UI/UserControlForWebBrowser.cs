﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebBrowser.Logic;
using System.IO;

namespace WebBrowser.UI
{
    public partial class UserControlForWebBrowser : UserControl
    {
       
        public UserControlForWebBrowser()
        {
            InitializeComponent();
        }
        
        Stack<String> BackLinks = new Stack<String>();
        Stack<String> ForwardLinks = new Stack<String>();
        public String currentURL;


        


        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }
 
        public void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

            if (e.Url.Equals(webBrowser1.Url) && webBrowser1.ReadyState == WebBrowserReadyState.Complete)
            {
                var item = new HistoryItem();
                item.URL = toolStripComboBox1.Text.ToString();
                item.Title = webBrowser1.DocumentTitle;
                item.Date = DateTime.Now;
                HistoryManager.AddItem(item);



                progressBarLabel.Text = "done";
                progressBar.Visible = false;

               


            }
        }


        private void toolStripButton5_Click(object sender, EventArgs e)
        {//GREEN ENTER BUTTON
            progressBar.Visible = true;
            progressBarLabel.Text = "loading";
            webBrowser1.Navigate(toolStripComboBox1.Text.ToString());
            currentURL = toolStripComboBox1.Text.ToString();
            webBrowser1.Navigate(currentURL);
            BackLinks.Push(currentURL);
            pictureBox1.Visible = false;

            
            
           


        }

        private void toolStripComboBox1_Click_KeyUp(object sender, KeyEventArgs e)
        {//ADDRESS BAR

            if (e.KeyCode == Keys.Enter)
            {
                progressBar.Visible = true;
                progressBarLabel.Text = "loading";
                if (currentURL != null)
                {
                    BackLinks.Push(currentURL);
                    toolStripButton2.Enabled = true;
                }
                currentURL = toolStripComboBox1.Text.ToString();
                webBrowser1.Navigate(currentURL);
                pictureBox1.Visible = false;




            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {//BACK BUTTON
            
        
           toolStripComboBox1.Text = currentURL;
            
                     if (BackLinks.Count == 1)
                     {

                        toolStripButton2.Enabled = false;

                     }
                     else
                    
                         progressBar.Visible = true;
                         progressBarLabel.Text = "loading";
                         ForwardLinks.Push(currentURL);
                         toolStripButton3.Enabled = true;
                         currentURL = BackLinks.Pop();
                         webBrowser1.Navigate(currentURL);
                         toolStripComboBox1.Text = currentURL;
                  


        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {//FORWARD BUTTON

            if (ForwardLinks.Count == 1)
            {
                toolStripButton3.Enabled = false;
            }

            progressBar.Visible = true;
            progressBarLabel.Text = "loading";
            BackLinks.Push(currentURL);
            toolStripButton2.Enabled = true;
            currentURL = ForwardLinks.Pop();
            webBrowser1.Navigate(currentURL);
            toolStripComboBox1.Text = currentURL;
   
           
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        public String getURL()
        {
            return toolStripComboBox1.Text.ToString();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {//Bookmark button

            var item = new BookmarkItem();
            item.URL = toolStripComboBox1.Text;
            item.Title = webBrowser1.DocumentTitle;
            BookmarkManager.AddItem(item);

        }
        public void PrintDocument()
        {//print function
            if (printDialog1.ShowDialog() == DialogResult.OK)
            {

                webBrowser1.Print();
            }


        }
        public void Save()
        {//save function

            saveFileDialog1.Filter = "HTML Files|.html";
            saveFileDialog1.RestoreDirectory = true;


            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {


                using (System.IO.FileStream fs = (System.IO.FileStream)saveFileDialog1.OpenFile())
                {
                    using (StreamWriter sw = new StreamWriter(fs, Encoding.Default))
                    {
                        sw.Write(webBrowser1.DocumentText);
                    }
                }
            }
        }


        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void saveFile_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {//HOME BUTTON

            progressBar.Visible = true;
            progressBarLabel.Text = "loading";
            webBrowser1.Navigate("www.google.com");
            toolStripComboBox1.Text = "www.google.com";
            BackLinks.Push("www.google.com");



        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }
    }



}

﻿namespace WebBrowser.Data
{


    partial class HistoryDataSet
    {
    }
}

namespace WebBrowser.Data.HistoryDataSetTableAdapters {
    
    
    public partial class HistoryTableAdapter {
    }
}
